package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import mt.Order;
import mt.comm.ServerComm;
import mt.comm.ServerSideMessage;
import mt.comm.ServerSideMessage.Type;
import mt.server.MicroTraderServer;
import mt.server.Server;
import mt.server.ServerCommImp;

public class ServerMainTest {

	@Test
	public void test() {
		ServerComm serverComm = new ServerCommImp();
		MicroTraderServer server = new Server();
		
	}

}
