package mt.server;

import java.util.Stack;

import mt.Order;
import mt.comm.ServerComm;
import mt.comm.ServerSideMessage;

public class ServerCommImp extends Thread implements ServerComm {
	
	private Stack<ServerSideMessage> mensagens = new Stack<ServerSideMessage>();
	
	@Override
	public void start() {
		while(true){
			try {
				sleep(2000);
				// exemplo
				this.sendOrder("Trader1", Order.createBuyOrder("Trader1", "APPLE", 10, 120.32));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}



	@Override
	public boolean hasNextMessage() {
		return !mensagens.isEmpty();
	}

	@Override
	public ServerSideMessage getNextMessage() {
		if(hasNextMessage()){
			return mensagens.pop();
		}else{
			return null;
		}
	}

	@Override
	public void sendError(String toNickname, String error) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean clientIsConnected(String nickname) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void disconnectClient(String nickname) {
		// TODO Auto-generated method stub
	}

	@Override
	public void sendOrder(String receiversNickname, Order order) {
		mensagens.push(new Message(ServerSideMessage.Type.NEW_ORDER, receiversNickname, order));
	}

}
