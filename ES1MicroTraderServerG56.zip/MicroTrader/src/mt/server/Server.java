package mt.server;

import java.util.ArrayList;
import java.util.List;

import mt.Order;
import mt.comm.ServerComm;
import mt.comm.ServerSideMessage;
import mt.comm.ServerSideMessage.Type;

public class Server implements MicroTraderServer {

	//Connected clients list
	private List<Client> clientsList = null;
	
	//Active order list
	private List<Order> orderList = null;
	
	private ServerComm serverComm = null;
	
	
	@Override
	public void start(ServerComm serverComm) {
		this.clientsList = new ArrayList<Client>();
		this.serverComm = serverComm;
		
		new Thread() {
			public synchronized void run() {
				while (true) {
					while (!serverComm.hasNextMessage()) {
						try {
							System.out.println("> A espera de novas mensagens...");
							wait(200);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					while (serverComm.hasNextMessage()) {
						System.out.println("> Foi encontrada uma nova mensagem...");
						ServerSideMessage sSMsg=readMessage();
						if (sSMsg.getType() ==Type.CONNECTED)
							handleClientConnection(sSMsg);
						else if (sSMsg.getType()==Type.DISCONNECTED)
							handleClientDisconnected(sSMsg);
						else if (sSMsg.getType()==Type.NEW_ORDER){
							handleNewOrders(sSMsg);
						}
						
					}
				}
			}
		}.start();
		serverComm.start();
	}
	
	//This reads the message received and returns a ServerSideMessage with all the respective Order,Nickname and type
	private ServerSideMessage readMessage(){
		ServerSideMessage sSMsg = this.serverComm.getNextMessage();
		return sSMsg;
	}

	//this checks if a client is already connected or not to the server
	protected Client getConnectedClientByNickname(String nickname) {
		int size = this.clientsList.size();
		for (int i = 0; i < size; i++) {
			if (this.clientsList.get(i).getSenderNickname().equals(nickname)) {
				return this.clientsList.get(i);
			}
		}
		return null;
	}
	
	//This handles the messages whose type is Connected and adds those clients to the list if not already there
	private void handleClientConnection(ServerSideMessage msg){
			if (getConnectedClientByNickname(msg.getSenderNickname()) != null) {
				this.serverComm.sendError(msg.getSenderNickname(), ServerErrorMessage.CLIENT_ALREADY_CONNECTED.toString());
			} else {
				this.clientsList.add(new Client(msg.getSenderNickname()));
			}
	}
	
	//This handles the messages whose type is Disconnected and removes the client in question
	public void handleClientDisconnected(ServerSideMessage msg) {
			Client clientToDisconnect = getConnectedClientByNickname(msg.getSenderNickname());
			if (clientToDisconnect != null){
				this.clientsList.remove(clientToDisconnect);
			} else {
				this.serverComm.sendError(msg.getSenderNickname(), ServerErrorMessage.CLIENT_NOT_CONNECTED.toString());
			}
	}
	
	//This handles the creation of a new order ID
	public void handleNewOrderId(Order order) {
		Client client = getConnectedClientByNickname(order.getNickname());
		if(client != null){
			int id = 1000;
			order.setServerOrderID(id);
			id++;
			}else {
				this.serverComm.sendError(order.getNickname(), ServerErrorMessage.CLIENT_NOT_CONNECTED.toString());
			}
	}
	
	public void handleNewOrders(ServerSideMessage message){
		
		int listNumberOfUnits=0;
		int messageNumberOfUnits=0;
		double listPrice = 0;
		double messagePrice = 0;
		//this boolean will work to check if the list is changed with the order received, in case it hasn't it will
		//add this new order to the orderList
		boolean listChecker=false;
		
		System.out.println("> A processar nova ordem... " + message);
		Client cliente = getConnectedClientByNickname(message.getSenderNickname());
		//verification if client exists
		if(cliente != null){
			if (orderList.isEmpty()){
				orderList.add(message.getOrder());
				handleNewOrderId(orderList.get(0));
			}
			
			//verification in case order received is a Buy Order
			if (message.getOrder().isBuyOrder()){
				for(int i=0;i<orderList.size();i++){
					if(orderList.get(i).isSellOrder()){
						
						//verification if product name is the desired one
						if(orderList.get(i).getStock().equals(message.getOrder().getStock())){
							listNumberOfUnits=orderList.get(i).getNumberOfUnits();
							messageNumberOfUnits=message.getOrder().getNumberOfUnits();
							listPrice = orderList.get(i).getPricePerUnit();
							messagePrice = message.getOrder().getPricePerUnit();
							
							//if list price is lower or equal to buy order, the purchase goes through
							if (listPrice<=messagePrice){
								if (listNumberOfUnits>messageNumberOfUnits){
									listChecker=true;
									listNumberOfUnits=listNumberOfUnits-messageNumberOfUnits;
									if (listNumberOfUnits==0)
										orderList.remove(i);
									else
										orderList.get(i).setNumberOfUnits(listNumberOfUnits);
								}else if (listNumberOfUnits<messageNumberOfUnits) {
									orderList.remove(i);
									messageNumberOfUnits=messageNumberOfUnits-listNumberOfUnits;
									message.getOrder().setNumberOfUnits(messageNumberOfUnits);
								}
							}
						}	
					}
				}
			//verification in case order received is a Sell Order
			} else if (message.getOrder().isSellOrder()){
				for(int i=0;i<orderList.size();i++){
					if(orderList.get(i).isBuyOrder()){
						if(orderList.get(i).getStock().equals(message.getOrder().getStock())){
							listNumberOfUnits=orderList.get(i).getNumberOfUnits();
							messageNumberOfUnits=message.getOrder().getNumberOfUnits();
							listPrice = orderList.get(i).getPricePerUnit();
							messagePrice = message.getOrder().getPricePerUnit();
							
							//if list price is higher or equal to sell order, the purchase goes through
							if (listPrice>=messagePrice){
								if (listNumberOfUnits>messageNumberOfUnits){
									listChecker=true;
									listNumberOfUnits=listNumberOfUnits-messageNumberOfUnits;
									if(listNumberOfUnits==0)
										orderList.remove(i);
									else
										orderList.get(i).setNumberOfUnits(listNumberOfUnits);
								}else if (listNumberOfUnits<messageNumberOfUnits) {
									orderList.remove(i);
									messageNumberOfUnits=messageNumberOfUnits-listNumberOfUnits;
									message.getOrder().setNumberOfUnits(messageNumberOfUnits);
								}
							}
						}
					}
				}
			//this part is explained at the listChecker variable declaration
			}else if(listChecker==false){
				orderList.add(message.getOrder());
				handleNewOrderId(orderList.get(orderList.size()));
			}
		}
	}

}
