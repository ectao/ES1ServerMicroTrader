package mt.server;

public enum ServerErrorMessage {
	CLIENT_ALREADY_CONNECTED("ERROR: Client is already connected."), 
	CLIENT_NOT_CONNECTED("ERROR: Client is not connected.");

	private String message;
    private ServerErrorMessage(String message) {
            this.message = message;
    }


}
