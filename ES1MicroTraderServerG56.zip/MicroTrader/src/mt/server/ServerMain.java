package mt.server;

import mt.comm.ServerComm;
import mt.server.MicroTraderServer;

public class ServerMain {	
	
	public static void main(String[] args) {
		ServerComm serverComm = new ServerCommImp();
		MicroTraderServer server = new Server();
		server.start(serverComm);
	}
	
}
