package mt.server;

import mt.Order;
import mt.comm.ServerSideMessage;

public class Message implements ServerSideMessage{

	private Type type;
	private String senderNickname;
	private Order order;
	
	public Message(Type type, String senderNickname, Order order) {
		this.type = type;
		this.senderNickname = senderNickname;
		this.order = order;
	}
	
	@Override
	public Type getType() {
		return type;
	}

	@Override
	public String getSenderNickname() {
		return senderNickname;
	}

	@Override
	public Order getOrder() {
		return order;
	}

	@Override
	public String toString() {
		return "Message [type=" + type + ", senderNickname=" + senderNickname + ", order=" + order + "]";
	}
	
}
