package mt.server;

public class Client {
		
		private String nick;
		
		Client(String nickname) 
		{
			this.nick = nickname;
		}

		
		public String getSenderNickname() {
			return this.nick;
		}
	}


