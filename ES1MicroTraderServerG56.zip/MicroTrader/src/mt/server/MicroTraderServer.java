package mt.server;

import mt.comm.ServerComm;

/**
 * The server is responsible for matching orders from clients and for keeping clients up to date with unfulfilled orders.
 * 
 * @author alc
 *
 */

public interface MicroTraderServer {
	/**
	 * Starts the server. Should only exit when the server quits.
	 * 
	 * @param serverComm the object through which all communication with clients should take place.
	 */
	public void start(ServerComm serverComm);
	
	// Ent�o meus meninos, aqui � suposto fazer-mos o server start, o server disconnect e tendo em conta o 
	//que est� incluido na parte do ServerCommDummy, temos de criar fun��es que utilizem o que elas devolvem, por exemplo:
	//no getNextMessage(): que devolve uma ServerSideMessage que pode ser do tipo, new order, connected e disconnect tem
	//de testar o tipo de mensagem e se for disconect vamos retirar esse client da lista de clientes, se for connect adicionamos o client 
	// � lista, e se for new order h� que testar se essa order � uma buy order ou sell order e verificar a lista de ordens a verificar
	// se ha para venda ou se h� para compra, todas estas listas irao ser listas de objectos.
	//Ter em mente que isto � suposto ser software para compras e vendas. Todas as classes e fun�oes fora do ServerComm n�o s�o para ser
	//feitas, mas para assumir que funcionam bem.
	//Sempre que fizerem altera��es usem o // ou o /* */ para escrever comments a explicar a parte que fizeram.
	
}
