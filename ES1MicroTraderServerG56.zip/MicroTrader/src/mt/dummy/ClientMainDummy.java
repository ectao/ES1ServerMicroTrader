package mt.dummy;

import mt.client.MicroTraderClient;

public class ClientMainDummy {	
	public static void main(String[] args) {
		ClientCommDummy clientComm = new ClientCommDummy();
		MicroTraderClient  client     = new MicroTraderClientDummy();
		client.start(clientComm);
	}
}
