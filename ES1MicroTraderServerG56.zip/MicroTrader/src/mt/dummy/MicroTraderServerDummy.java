package mt.dummy;

import mt.comm.ServerComm;
import mt.server.MicroTraderServer;

public class MicroTraderServerDummy implements MicroTraderServer {

	@Override
	public void start(ServerComm serverComm) {
		// TODO Auto-generated method stub
		
	}

}
