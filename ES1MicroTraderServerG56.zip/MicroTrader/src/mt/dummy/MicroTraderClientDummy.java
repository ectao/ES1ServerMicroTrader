package mt.dummy;

import mt.client.MicroTraderClient;
import mt.comm.ClientComm;

public class MicroTraderClientDummy implements MicroTraderClient {

	@Override
	public void start(ClientComm clientComm) {
		// TODO Auto-generated method stub
	}

}
